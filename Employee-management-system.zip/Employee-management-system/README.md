# Employee-management-system
Employee Management System built using Spring Boot and MySQL
